<?php

if (!defined('ABSPATH')) die('No direct access.');

/**
 * Use this file to load in models and libraries.
 */
require_once(dirname(__FILE__) . '/Settings.php');
require_once(dirname(__FILE__) . '/Slideshows.php');
require_once(dirname(__FILE__) . '/slides/Slide.php');
require_once(dirname(__FILE__) . '/Themes.php');
require_once(dirname(__FILE__) . '/Image.php');