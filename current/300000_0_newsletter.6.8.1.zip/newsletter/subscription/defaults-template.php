<?php

// This file is used only on first installation!

$options = array();
$options['template'] = @file_get_contents(__DIR__ . '/email.html');
