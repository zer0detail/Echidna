<?php if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); } ?>
<h1 class="wp-heading-inline" style="margin-bottom:15px;"><?php echo esc_html($page_title); ?></h1>
